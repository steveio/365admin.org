---
title: 7 square fill
categories:
  - Shapes
tags:
  - number
  - numeral
---
