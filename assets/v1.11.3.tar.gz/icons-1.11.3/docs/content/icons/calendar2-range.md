---
title: Calendar2 range
categories:
  - Date and time
tags:
  - dates
  - timeline
  - duration

---
