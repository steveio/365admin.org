<?

require_once("./conf/config.php");
require_once("./init.php");
require_once("/www/vhosts/365admin.org/htdocs/conf/brand_config.php");


// Process URI / Request ------------------------------------------


$request_array = Request::GetUri("ARRAY");

Logger::DB(2,"API request: /".implode("/",$request_array));



if (is_array($request_array)) {
	foreach($request_array as $uri_segment) {
		if ($uri_segment == "") continue;
		if (!NameService::validUriNamespaceIdentifier($uri_segment)) {
			throw new Exception("Invalid uri segment: ".$uri_segment);
			die();
		}
	}
}

$permitted_hosts = array("oneworld365.org", "gapyear365.com", "seasonaljobs365.com","summercamp365.com", "tefl365.com");
$hostname = Request::GetHostName();

if (!in_array(strtolower($hostname), $permitted_hosts)) {
	throw new Exception("Invalid hostname: ".$hostname);
	die();
}

$permitted_methods = array("search");

if (!in_array(strtolower($request_array[1]), $permitted_methods)) {
	throw new Exception("Invalid API method: ".$hostname);
	die();
}


// Build Search Query Parameters ---------------------------------

$query = "";
$fq = array();
$aFacetField = array();
$aFacetQuery = array();


if (strtolower($request_array[2]) == "search") {
	$fq = array();
	$query = preg_replace("/-/"," ",$request_array[3]);
}
if (strtolower($request_array[2]) == "category") {
	$a = NameService::lookupNameSpaceIdentifier("category",$request_array[3]);
	$fq = array('category_id' => $a['id']);
	$query = $a['name'];

	// add a facet fields
	$aFacetField[] = array("country" => "country");
	$aFacetField[] = array("continent" => "continent");
	$aFacetField[] = array("activity" => "activity");

	// add facet query
	$aFacetQuery['price'][] = array('price_from_1' => 'price_from:[* TO 500]');
	$aFacetQuery['price'][] = array('price_from_2' => 'price_from:[500 TO 750]');
	$aFacetQuery['price'][] = array('price_from_3' => 'price_from:[750 TO 1250]');
	$aFacetQuery['price'][] = array('price_from_4' => 'price_from:[1250 TO 2000]');
	$aFacetQuery['price'][] = array('price_from_5' => 'price_from:[2000 TO *]');

	$aFacetQuery['duration'][] = array('duration_1' => 'duration_from:[1 TO 2]');
	$aFacetQuery['duration'][] = array('duration_2' => 'duration_from:[2 TO 4]');
	$aFacetQuery['duration'][] = array('duration_3' => 'duration_from:[4 TO 6]');
	$aFacetQuery['duration'][] = array('duration_4' => 'duration_from:[6 TO 8]');
	$aFacetQuery['duration'][] = array('duration_5' => 'duration_from:[8 TO *]');
	
}
if (strtolower($request_array[2]) == "activity") {
	$a = NameService::lookupNameSpaceIdentifier("activity",$request_array[3]);
	$fq = array('activity_id' => $a['id']);
	$query = $a['name'];

	// add a facet fields
	$aFacetField[] = array("country" => "country");
	$aFacetField[] = array("continent" => "continent");
	$aFacetField[] = array("activity" => "category");

	// add facet query
	$aFacetQuery['price'][] = array('price_from_1' => 'price_from:[* TO 500]');
	$aFacetQuery['price'][] = array('price_from_2' => 'price_from:[500 TO 750]');
	$aFacetQuery['price'][] = array('price_from_3' => 'price_from:[750 TO 1250]');
	$aFacetQuery['price'][] = array('price_from_4' => 'price_from:[1250 TO 2000]');
	$aFacetQuery['price'][] = array('price_from_5' => 'price_from:[2000 TO *]');
	
	$aFacetQuery['duration'][] = array('duration_1' => 'duration_from:[1 TO 2]');
	$aFacetQuery['duration'][] = array('duration_2' => 'duration_from:[2 TO 4]');
	$aFacetQuery['duration'][] = array('duration_3' => 'duration_from:[4 TO 6]');
	$aFacetQuery['duration'][] = array('duration_4' => 'duration_from:[6 TO 8]');
	$aFacetQuery['duration'][] = array('duration_5' => 'duration_from:[8 TO *]');
	
}
if (strtolower($request_array[2]) == "travel") {
	$a = NameService::lookupNameSpaceIdentifier("country",$request_array[3]);
	$fq = array('country_id' => $a['id']);
	if (strlen($request_array[4]) >= 1) { // eg /travel/south-africa/volunteer-in-south-africa
		$query = preg_replace("/-/"," ",$request_array[4]);
	} else {
		$query = $a['name'];
	}
	
	$aFacetField[] = array("activity" => "activity");
	$aFacetField[] = array("category" => "category");
	
	// add facet query
	$aFacetQuery['price'][] = array('price_from_1' => 'price_from:[* TO 500]');
	$aFacetQuery['price'][] = array('price_from_2' => 'price_from:[500 TO 750]');
	$aFacetQuery['price'][] = array('price_from_3' => 'price_from:[750 TO 1250]');
	$aFacetQuery['price'][] = array('price_from_4' => 'price_from:[1250 TO 2000]');
	$aFacetQuery['price'][] = array('price_from_5' => 'price_from:[2000 TO *]');
	
	$aFacetQuery['duration'][] = array('duration_1' => 'duration_from:[1 TO 2]');
	$aFacetQuery['duration'][] = array('duration_2' => 'duration_from:[2 TO 4]');
	$aFacetQuery['duration'][] = array('duration_3' => 'duration_from:[4 TO 6]');
	$aFacetQuery['duration'][] = array('duration_4' => 'duration_from:[6 TO 8]');
	$aFacetQuery['duration'][] = array('duration_5' => 'duration_from:[8 TO *]');
	
}
if (strtolower($request_array[2]) == "continent") {
	$a = NameService::lookupNameSpaceIdentifier("continent",$request_array[3]);
	$fq = array('continent_id' => $a['id']);
	if (strlen($request_array[4]) >= 1) { // eg /continent/asia/teach-in-asia
		$query = preg_replace("/-/"," ",$request_array[4]);
	} else {
		$query = $a['name'];
	}
	$aFacetField[] = array("country" => "country");
	$aFacetField[] = array("category" => "category");
	$aFacetField[] = array("activity" => "activity");
	
	// add facet query
	$aFacetQuery['price'][] = array('price_from_1' => 'price_from:[* TO 500]');
	$aFacetQuery['price'][] = array('price_from_2' => 'price_from:[500 TO 750]');
	$aFacetQuery['price'][] = array('price_from_3' => 'price_from:[750 TO 1250]');
	$aFacetQuery['price'][] = array('price_from_4' => 'price_from:[1250 TO 2000]');
	$aFacetQuery['price'][] = array('price_from_5' => 'price_from:[2000 TO *]');
	
	$aFacetQuery['duration'][] = array('duration_1' => 'duration_from:[1 TO 2]');
	$aFacetQuery['duration'][] = array('duration_2' => 'duration_from:[2 TO 4]');
	$aFacetQuery['duration'][] = array('duration_3' => 'duration_from:[4 TO 6]');
	$aFacetQuery['duration'][] = array('duration_4' => 'duration_from:[6 TO 8]');
	$aFacetQuery['duration'][] = array('duration_5' => 'duration_from:[8 TO *]');
	
}

Logger::DB(2,"API query: ".$query);
Logger::DB(2,"API fq: ".json_encode($fq));



// RUN SEARCH ------------------------------------------------------

$iRows = (is_numeric($_REQUEST['rows']) && $_REQUEST['rows'] < 1000) ? $_REQUEST['rows'] : 24;
$iStart = is_numeric($_REQUEST['start']) ? (($_REQUEST['start'] -1) * $iRows) : 0;

Logger::DB(2,"API rows: ".$iRows.", start: ".$iStart);


$oSolrPlacementSearch = new SolrPlacementSearch($solr_config);
$oSolrPlacementSearch->setRows($iRows);
$oSolrPlacementSearch->setStart($iStart);

// add facetField
if (count($aFacetField) >= 1) {
	foreach($aFacetField as $facet) {
		$oSolrPlacementSearch->addFacetField($facet);
	}
}

// add facetQuery
if (count($aFacetQuery) >= 1) {
	foreach($aFacetQuery as $key => $facetQuerySet) {
		$oSolrPlacementSearch->addFacetQuery($key,$facetQuerySet);
	}
}

$oSolrPlacementSearch->search($query,$fq);

$aPlacementId = $oSolrPlacementSearch->getPlacementId();
$aPlacementProfile = array();
if (is_array($aPlacementId) && count($aPlacementId) >= 1) {
	$aPlacementProfile = PlacementProfile::Get("ID_LIST_SEARCH_RESULT",$aPlacementId);
}

Logger::DB(2,"API Found placement_id: ".count($aPlacementId).", placement_profiles: ".count($aPlacementProfile));

if (!is_array($aPlacementProfile)) {
	throw new Exception("API 0 Placement profiles returned from PlacementProfile::Get()");
}


// JSON encode Profiles --------------------------------------------

$aResponse = array();
$aResponse['status'] = true;
$aResponse['data'] = array();



foreach($aPlacementProfile as $oProfile) {
	$aResponse['data']['profile'][] = $oProfile->toJSON();
}

// add any facetField results
if (count($aFacetField) >= 1) {
	foreach($aFacetField as $facet) {
		foreach($facet as $key => $value) {
			$aResponse['data']['facet'][$key]['name'] = $key;
			$aResponse['data']['facet'][$key]['data'] = $oSolrPlacementSearch->getFacetFieldResult($key);
		}
	}
}

// add any facetQuery results
if (count($aFacetQuery) >= 1) {
	foreach($aFacetQuery as $key => $facetQuerySet) {		
		$aResponse['data']['facet'][$key]['name'] = $key;
		$aResponse['data']['facet'][$key]['data'] = $oSolrPlacementSearch->getFacetQueryResult($key);
	}
}


//var_dump($oSolrPlacementSearch->getFacetFieldResult('country'));

//var_dump($aResponse);
//die();
//var_dump(json_encode($aResponse));


header('Content-type: application/x-json');
echo $_GET['callback'] . '('.json_encode($aResponse).')';
die();



?>
