<?


require_once("./conf/config.php");
require_once("./init.php");
require_once("/www/vhosts/365admin.org/htdocs/conf/brand_config.php");

// Process URI / Request ------------------------------------------



$request_array = Request::GetUri("ARRAY");

Logger::DB(2,"API request: /".implode("/",$request_array));



if (is_array($request_array)) {
	foreach($request_array as $uri_segment) {
		if ($uri_segment == "") continue;
		if (!NameService::validUriNamespaceIdentifier($uri_segment)) {
			throw new Exception("Invalid uri segment: ".$uri_segment);
			die();
		}
	}
}

$permitted_hosts = array("oneworld365.org", "gapyear365.com", "seasonaljobs365.com","summercamp365.com", "tefl365.com");
$hostname = Request::GetHostName();

if (!in_array(strtolower($hostname), $permitted_hosts)) {
	throw new Exception("Invalid hostname: ".$hostname);
	die();
}

$permitted_methods = array("search");

if (!in_array(strtolower($request_array[1]), $permitted_methods)) {
	throw new Exception("Invalid API method: ".$hostname);
	die();
}


// Build Search Query Parameters ---------------------------------

$query = "";
$fq = array();


if (strtolower($request_array[2]) == "category") {
	$a = NameService::lookupNameSpaceIdentifier("category",$request_array[3]);
	$fq = array('category_id' => $a['id']);
	$query = $a['name'];
}
if (strtolower($request_array[2]) == "activity") {
	$a = NameService::lookupNameSpaceIdentifier("activity",$request_array[3]);
	$fq = array('activity_id' => $a['id']);
	$query = $a['name'];

}
if (strtolower($request_array[2]) == "travel") {
	$a = NameService::lookupNameSpaceIdentifier("country",$request_array[3]);
	$fq = array('country_id' => $a['id']);
	if (strlen($request_array[4]) >= 1) { // eg /travel/south-africa/volunteer-in-south-africa
		$query = preg_replace("/-/"," ",$request_array[4]);
	} else {
		$query = $a['name'];
	}
}
if (strtolower($request_array[2]) == "continent") {
	$a = NameService::lookupNameSpaceIdentifier("continent",$request_array[3]);
	$fq = array('continent_id' => $a['id']);
	if (strlen($request_array[4]) >= 1) { // eg /continent/asia/teach-in-asia
		$query = preg_replace("/-/"," ",$request_array[4]);
	} else {
		$query = $a['name'];
	}

}

Logger::DB(2,"API query: ".$query);
Logger::DB(2,"API fq: ".json_encode($fq));



// RUN SEARCH ------------------------------------------------------

$iRows = (is_numeric($_REQUEST['rows']) && $_REQUEST['rows'] < 1000) ? $_REQUEST['rows'] : 24;
$iStart = is_numeric($_REQUEST['start']) ? (($_REQUEST['start'] -1) * $iRows) : 0;

Logger::DB(2,"API rows: ".$iRows.", start: ".$iStart);


$oSolrPlacementSearch = new SolrPlacementSearch($solr_config);
$oSolrPlacementSearch->setRows($iRows);
$oSolrPlacementSearch->setStart($iStart);
$oSolrPlacementSearch->search($query,$fq);
$aPlacementId = $oSolrPlacementSearch->getPlacementId();
$aPlacementProfile = array();
if (is_array($aPlacementId) && count($aPlacementId) >= 1) {
	$aPlacementProfile = PlacementProfile::Get("ID_LIST_SEARCH_RESULT",$aPlacementId);
}

Logger::DB(2,"API Found placement_id: ".count($aPlacementId).", placement_profiles: ".count($aPlacementProfile));

if (!is_array($aPlacementProfile)) {
	throw new Exception("API 0 Placement profiles returned from PlacementProfile::Get()");
}


// JSON encode Profiles --------------------------------------------

$aResponse = array();
$aResponse['status'] = true;
$aResponse['data'] = array();



foreach($aPlacementProfile as $oProfile) {
	$aResponse['data'][] = $oProfile->toJSON();
}

//var_dump(json_encode($aProfileSummary));

//var_dump($aResponse);
//var_dump(json_encode($aResponse));


header('Content-type: application/x-json');
echo $_GET['callback'] . '('.json_encode($aResponse).')';
die();



?>
