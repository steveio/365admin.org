#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

int main(void)
{
    /*
    char buffer[300] = "66 ba f8 03";

    uint8_t code[1000];

    long val;
    char *endptr;

    char* token = strtok(buffer, " ");
    // Keep printing tokens while one of the
    // delimiters present in str[].
    int pc = 0;
    while (token != NULL) {

        // convert as a base16 number
        val = strtol(token, &endptr, 16);

        // The character following the number should be the end of the string as the input string is already tokenized.
        if(*endptr) {
            // error handling
        } else if(val < 0) {
            // error handling
        } else if(val > UINT8_MAX) {
            // error handling
        } else {
            // The checks above make sure that the value fits into uint8_t.
            code[pc] = (uint8_t)val;
        }

        token = strtok(NULL, " ");
        pc++;
    }

    for(int i = 0; i < pc; i++) {
        printf("code[%d] = 0x%02x\n", i, code[i]);
    }
    */

    char buffer[300] = "32 128 255 256 00";

    uint8_t code[1000];

    long val;
    char *endptr;

    char* token = strtok(buffer, " ");
    // Keep printing tokens while one of the
    // delimiters present in str[].
    int pc = 0;
    while (token != NULL) {

        /* convert as a base16 number */
        val = strtol(token, &endptr, 10);

        /* The character following the number should be the end of the string as the input string is already tokenized. */
        if(*endptr) {
            printf("UINT8_CONVERT ERR");

        } else if(val < 0) {
            printf("UINT8_RANGE ERR");
        } else if(val > UINT8_MAX) {
            printf("UINT8_LEN ERR");
        } else {
            /* The checks above make sure that the value fits into uint8_t. */
            code[pc] = (uint8_t)val;
        }

        token = strtok(NULL, " ");
        pc++;
    }

    for(int i = 0; i < pc; i++) {
        printf("code[%d] = %d\n", i, code[i]);
    }

    return 0;
}
