#include <stdio.h>


typedef struct
{
    int encoding;
    int length;
    char * array;
} EncodedString;

void printString(EncodedString str);

int main(void)
{

    char c[] = "abc";
    EncodedString mystring = {1, sizeof c, c};

    printString(mystring);
    printf("\n");

    return 0;

}

void printString(EncodedString str) // <--- where I try to print the character
{
    int i;
    printf("%d\n",str.length);
    for(i = 0; i < str.length; i++)
    {
        printf("%x \t", str.array[i]);
        printf("%c \t", str.array[i]);
    }
}
