#include <stdio.h>
#include <string.h>
#include <stdint.h>

struct msg
{
  int id;
  char space;
  char cmdmsg[3];
  char CR;
  char LF;
};

void print_binary(uint8_t number)
{
    if (number >> 1) {
        print_binary(number >> 1);
    }
    printf("%c",(number & 1) ? '1' : '0');
}


/*
void USARTWrite(const void *object, size_t size)
{
    const unsigned char *byte;
    for ( byte = object; size--; ++byte )
    {
        printf("0x%02x\n", *byte);
    }
    putchar('\n');
}
*/
void USARTWrite(const void *object, size_t size)
{
    const uint8_t * byte;
    for ( byte = object; size--; ++byte )
    {
        printf("0x%02x\t", *byte);
        print_binary((uint8_t)*byte);
        putchar('\n');
    }
    putchar('\n');
}



int main (int argc, char**argv)
{
    struct msg myMsg;
    myMsg.id = 67;
    myMsg.space = 0x20;
    myMsg.LF = 0x0A;
    myMsg.CR = 0x0D;

    char c[3] = "abc";
    strncpy(myMsg.cmdmsg, c, 3);

    //unsigned char* ptr = (unsigned char*)&myMsg;
    //USARTWrite(ptr, sizeof(myMsg));

    //uint8_t * ptr2 = (uint8_t*)&myMsg;
    uint8_t * bytePtr = (uint8_t*)&myMsg;
    USARTWrite(bytePtr, sizeof(myMsg));

    USARTWrite(&myMsg, sizeof(myMsg));

    //printf("%lu",sizeof(ptr));

    return 0;
}
