#include <stdlib.h>
#include <stdio.h>


#define SECS_PER_MIN  ((time_t)(60UL))
#define SECS_PER_HOUR ((time_t)(3600UL))
#define SECS_PER_DAY  ((time_t)(SECS_PER_HOUR * 24UL))


bool _checkBitSet(int n, long * l)
{
  bool b = (*l >> (long) n) & 1U;
  return b;
}

int getHourGMTFromTS(unsigned long ts)
{
  unsigned long elapsedT1 = ts % SECS_PER_DAY;
  unsigned long elapsedT2 = elapsedT1 % SECS_PER_HOUR;
  int h = (elapsedT1 - elapsedT2) / SECS_PER_HOUR;
  return h;
}

int getNextEvent(long * l, int h, int type = -1)
{
  bool c = _checkBitSet(h, l);

  for(int i=h+1; i<24; i++)
  {
    bool n = _checkBitSet(i, l);
    if (n != c)
    {
      if (type == -1 || n == type)
      {
        return i;
      }
    }
  }
  for(int i=0; i<=h; i++)
  {
    bool n = _checkBitSet(i, l);
    if (n != c)
    {
      if (type == -1 || n == type)
      {
        return i;
      }
    }
  }
}

int main()
{

  unsigned long ts = 1635880898;
  long bitmask = 0b00000000000111111111111111100000;
  long * l = &bitmask;


  printf("Current TS: %d\n",(int)ts);

  int h = getHourGMTFromTS(ts);

  printf("Hour: %d\n",(int)h);

  int nextEvent = getNextEvent(l, h, 0);

  printf("Next Event: %d\n",(int)nextEvent);

}
