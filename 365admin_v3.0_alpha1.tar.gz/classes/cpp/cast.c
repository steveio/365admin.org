/**
* cast.c - c methods to convert primative data types to ASCII characters
*  - aim for minimal code that will run on microcontroller architecture
*/

#include <math.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>

// gcc - Compile with math lib: gcc cast.c -o cast -lm
// C++ runtime libstdc++ requires libm, so if you compile a C++ program with GCC (g++), you will automatically get libm linked in

// locate C std library (glibc) .a (static) .so (shared object)
// gcc --print-file-name=libc.so

// nm - list symbols from object files
// nm /usr/lib/x86_64-linux-gnu/libc.so --defined-only | grep str


static double PRECISION = 0.00000000000001;
static int MAX_NUMBER_STRING_SIZE = 32;


/**
 * Double to ASCII
 * https://stackoverflow.com/questions/2302969/convert-a-float-to-a-string
 */
char * dtoa(char *s, double n) {
    // handle special cases
    if (isnan(n)) {
        strcpy(s, "nan");
    } else if (isinf(n)) {
        strcpy(s, "inf");
    } else if (n == 0.0) {
        strcpy(s, "0");
    } else {
        int digit, m, m1;
        char *c = s;
        int neg = (n < 0);
        if (neg)
            n = -n;
        // calculate magnitude
        m = log10(n);
        int useExp = (m >= 14 || (neg && m >= 9) || m <= -9);
        if (neg)
            *(c++) = '-';
        // set up for scientific notation
        if (useExp) {
            if (m < 0)
               m -= 1.0;
            n = n / pow(10.0, m);
            m1 = m;
            m = 0;
        }
        if (m < 1.0) {
            m = 0;
        }
        // convert the number
        while (n > PRECISION || m >= 0) {
            double weight = pow(10.0, m);
            if (weight > 0 && !isinf(weight)) {
                digit = floor(n / weight);
                n -= (digit * weight);
                *(c++) = '0' + digit;
            }
            if (m == 0 && n > 0)
                *(c++) = '.';
            m--;
        }
        if (useExp) {
            // convert the exponent
            int i, j;
            *(c++) = 'e';
            if (m1 > 0) {
                *(c++) = '+';
            } else {
                *(c++) = '-';
                m1 = -m1;
            }
            m = 0;
            while (m1 > 0) {
                *(c++) = '0' + m1 % 10;
                m1 /= 10;
                m++;
            }
            c -= m;
            for (i = 0, j = m-1; i<j; i++, j--) {
                // swap without temporary
                c[i] ^= c[j];
                c[j] ^= c[i];
                c[i] ^= c[j];
            }
            c += m;
        }
        *(c) = '\0';
    }
    return s;
}


// Reverses a string 'str' of length 'len'
void reverse(char* str, int len)
{
    int i = 0, j = len - 1, temp;
    while (i < j) {
        temp = str[i];
        str[i] = str[j];
        str[j] = temp;
        i++;
        j--;
    }
}

// Converts a given integer x to string str[].
// d is the number of digits required in the output.
// If d is more than the number of digits in x,
// then 0s are added at the beginning.
int intToStr(int x, char str[], int d)
{
    int i = 0;
    while (x) {
        str[i++] = (x % 10) + '0';
        x = x / 10;
    }

    // If number of digits required is more, then
    // add 0s at the beginning
    while (i < d)
        str[i++] = '0';

    reverse(str, i);
    str[i] = '\0';
    return i;
}

// Converts a floating-point/double number to a string.
// https://www.geeksforgeeks.org/convert-floating-point-number-string/
void ftoa(float n, char* res, int afterpoint)
{
    // Extract integer part
    int ipart = (int)n;

    // Extract floating part
    float fpart = n - (float)ipart;

    // convert integer part to string
    int i = intToStr(ipart, res, 0);

    // check for display option after point
    if (afterpoint != 0) {
        res[i] = '.'; // add dot

        // Get the value of fraction part upto given no.
        // of points after dot. The third parameter
        // is needed to handle cases like 233.007
        fpart = fpart * pow(10, afterpoint);

        intToStr((int)fpart, res + i + 1, afterpoint);
    }
}


int main()
{

  // add null terminators to make arrays proper C strings:
  char c_static[] = { 't', 'e', 'm', 'p', ':', '1', '7', '6', '.', '1', '2', '3', '4', '5',  '\0' };

  printf("value of c_static: %s\n", c_static);

  uint8_t i8 = 255;
  printf("Int: %d \n",i8);
  char arr[3];
  sprintf(arr,"%d",i8);
  printf("Char: %s \n",arr);
  printf("First char: %c \n",arr[0]);

  uint16_t i16 = 65535;
  printf("Int: %d \n",i16);
  char arr16[3];
  sprintf(arr16,"%d",i16);
  printf("Char: %s \n",arr16);
  printf("First char: %c \n",arr16[0]);

  // double to ASCII

  char s[MAX_NUMBER_STRING_SIZE];

  // range of doubles for testing
  int int_arr[5] = {
          1,
          3,
          5,
          9,
          15
      };

  for (int i = 0; i < 5; i++) {
      sprintf(s, "%d", int_arr[i]);
      printf("%d\n", int_arr[i]);
      // printf("%d: printf: %.14g, dtoa: %s\n", i+1, d[i], dtoa(s, d[i]));
  }


  double d[] = {
          0.0,
          42.0,
          1234567.89012345,
          0.000000000000018,
          555555.55555555555555555,
          -888888888888888.8888888,
          111111111111111111111111.2222222222
      };

  // (s_printf() float/double formats
  //printf("printf() double f:  %f \n",d);
  //printf("printf() double lf: %lf \n",d);
  //printf("printf() double g: "%.14g"\n",d);
  //printf("Sizeof double: %lu \n",sizeof(double));

  for (int i = 0; i < 7; i++) {
      double dd = d[i];
      sprintf(s, "%.14g", dd);
      printf("%d: printf: %.14g, sprintf: %s\n", i+1, d[i],s);
      //printf("%d: printf: %.14g, dtoa: %s\n", i+1, d[i], dtoa(s, d[i]));
  }

  for (int i = 0; i < 7; i++) {
      double dd = d[i];
      ftoa(dd, s, 8);
      printf("%d: printf: %.14g, ftoa(): %s\n", i+1, d[i],s);
  }

  for (int i = 0; i < 7; i++) {
      printf("%d: printf: %.14g, dtoa: %s\n", i+1, d[i], dtoa(s, d[i]));
  }


  for (int i = 0; i < 7; i++) {
      memcpy(s,&d[i],sizeof(d[i]));
      printf("%d: printf: %.14g, memcpy: %s\n", i+1, d[i], s);
  }


  /*  Yet to make these methods work


  printf("\n");

  // cast double to char array - pointer cast
  double *pd=&d;

  // c++ style:
  // foo = reinterpret_cast< int * >(bar);
  // char *pc = reinterpret_cast<char*>(pd);

  // c style:
  // foo = (int *)(bar);
  char *pc = (char *)(pd);

  //printf("%s", pc);

  for(size_t i=0; i<sizeof(double); i++)
  {
     char ch = *pc;
     //printf("%c",ch);
     //pc++;
  }

  /*
  for(size_t i=0; i<sizeof(double); i++)
  {
     char ch = *pc;
     pc++;
  }

  unsigned int x = 123;
  char y[3] = {'h', 'i', '\0'};
  float z = 1.23f;

  // The buffer we will be writing bytes into
  unsigned char outBuf[sizeof(x)+sizeof(y)+sizeof(z)];

  // A pointer we will advance whenever we write data
  unsigned char * p = outBuf;

  // Serialize "x" into outBuf
  unsigned int32_t neX = htonl(x);
  memcpy(p, &neX, sizeof(neX));
  p += sizeof(neX);

  // Serialize "y" into outBuf
  memcpy(p, y, sizeof(y));
  p += sizeof(y);

  // Serialize "z" into outBuf
  int32_t neZ = htonl(*(reinterpret_cast<int32_t *>(&z)));
  memcpy(p, &neZ, sizeof(neZ));
  p += sizeof(neZ);

  */

  return 0;
}
