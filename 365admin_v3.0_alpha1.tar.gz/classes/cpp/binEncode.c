#include <stdio.h>
#include <stdint.h>
#include <string.h>

void print_binary(uint8_t number)
{
    if (number >> 1) {
        print_binary(number >> 1);
    }
    printf("%c",(number & 1) ? '1' : '0');
}

void printBits(size_t const size, void const * const ptr)
{
    unsigned char *b = (unsigned char*) ptr;
    unsigned char byte;
    int i, j;

    for (i=size-1;i>=0;i--)
    {
        for (j=7;j>=0;j--)
        {
            byte = (b[i] >> j) & 1;
            printf("%u", byte);
        }
        printf("\t");
    }
    puts("");
}


void hexdump(const void *data, int size)
{
    const unsigned char *byte = data;

    while (size > 0)
    {
        size--;
        printf("%.2x ", *byte);
        byte++;
    }
}


int main()
{

  struct data_bytes1 {
      char * c;
  };

  struct data_bytes1 db1;
  db1.c = "abc";

  printf("%s\n",db1.c);
  printf("0x%01x\n", (uint8_t)*db1.c);

  // cast to uint8_t pointer, access it as an array
  printf("0x%02x\n", ((uint8_t *) &db1.c)[0]);
  printf("0x%02x\n", ((uint8_t *) &db1.c)[1]);
  printf("0x%02x\n", ((uint8_t *) &db1.c)[2]);



  union data_bytes {
      char * c;
      uint8_t bytes[4];
  };

  union data_bytes db;
  db.c = "abc";


  printf("0x%02x\n", db.bytes[0]);
  printf("0x%02x\n", db.bytes[1]);
  printf("0x%02x\n", db.bytes[2]);
  printf("0x%02x\n", db.bytes[4]);


  /*
  union data_bytes {
      uint32_t data;
      uint8_t bytes[4];
  };

  union data_bytes db;
  db.data = 0x12345678;
  printf("0x%02x\n", db.bytes[1]);


  union data_bytes {
      uint32_t data;
      uint8_t bytes[4];
  };

  uint32_t value = 0x12345678;
  union data_bytes db;
  db.data = value;

  // shift one byte to the right and extract the LSB
  printf("0x%02x\n", (value >> 0) & 0xff);
  // cast to uint8_t pointer, access it as an array
  printf("0x%02x\n", ((uint8_t *) &value)[1]);
  // cast to uint8_t pointer, access via pointer arithmetic
  printf("0x%02x\n", *(((uint8_t *) &value) + 1));
  // simply take the union field
  printf("0x%02x\n", db.bytes[1]);
  /*
  union float_inspection {
      float floatval;
      uint32_t intval;
  } fi;

  float f = 65.65625;
  fi.floatval = f;

  printf("0x%08x\n", fi.intval);
  // ..or then again with pointers
  printf("0x%08x\n", *((uint32_t *) &f));


  union float_inspection {
      float floatval;
      uint32_t intval;
      struct {
          uint32_t fraction:23;
          uint32_t exponent:8;
          uint32_t sign:1;
      };
  } fi;

  float f = 65.65625;
  uint32_t i = *((uint32_t *) &f);
  fi.floatval = f;

  printf("%d %d 0x%x\n", fi.sign, fi.exponent, fi.fraction);
  printf("%d %d 0x%x\n", (i >> 31), ((i >> 23) & 0xff), (i & 0x7fffff));

    /*
    int ii = 67;
    uint8_t ui = 67;
    float f = 3.14257f;
    printBits(sizeof(ii), &ii);
    printBits(sizeof(ui), &ui);
    printBits(sizeof(f), &f);

    float temp = 3.14257;
    uint8_t * b = (uint8_t *) &temp;
    //printf("%b\n");
    print_binary(*b);
    printf("\n");
    printBits(sizeof(temp), &temp);
    printf("\n");


    printf("%lu\n",sizeof(uint8_t));
    printf("%lu\n",sizeof(uint16_t));
    printf("%lu\n",sizeof(uint32_t));
    printf("%lu\n",sizeof(float));
    printf("%lu\n",sizeof(unsigned long));
    printf("%lu\n",sizeof(long));


    typedef union {
      float floatingPoint;
      float floatingPoint2;
      uint8_t binary[sizeof(float)];
    } binaryFloat;

    binaryFloat hi;
    hi.floatingPoint = 3.14257;
    hi.floatingPoint2 = 3.14257;
    //Serial.writeln(hi.binary,4);
    //printf("%b\n",hi.binary);

   print_binary(*hi.binary);
   printf("\t");
   print_binary(hi.binary[0]);
   printf("\t");
   print_binary(hi.binary[2]);
   printf("\t");
   print_binary(hi.binary[4]);
   printf("\t\n");


   typedef struct data_t
   {
     uint8_t v0;
     uint8_t v1;
     float v2;
     const char * msg;
   } data;

   // message packaging / envelope
   typedef union packet_t
   {
    struct data_t data;
    uint8_t packet[sizeof(struct data_t)];
  } packet;

   union packet_t sendMsg;

   sendMsg.data.v0 = 67;
   sendMsg.data.v1 = 67;
   sendMsg.data.v2 = 3.14257;

   const char* p = "abc";

   printf("\n\n");
   int k;
   printf("%lu\n",sizeof p);
   for(k = 0; k < sizeof p; k++)
   {
       printf("%x ", p[k]);
       printf("%c ", p[k]);
   }
   printf("\n\n");

   typedef struct charmsg_t
   {
     const char * msg;
   } cmsg;


   //print_binary(p);
   printf("\n\n");
   printBits(sizeof(p), &p);
   hexdump( &p, sizeof(p));
   printf("\n\n");

   sendMsg.data.msg = p;

   //const char *ptr = "test";
   // size_t length = strlen(ptr);
   //char c[] = "test test";
   //size_t length = strlen(c);
   //printf("Msg: %lu\n",length);
   //strncpy(c, sendMsg.data.msg, length);


   printBits(sizeof(struct data_t), &sendMsg);

   hexdump( &sendMsg, sizeof(struct data_t));


  print_binary(sendMsg.packet[0]);
  printf("\t");
  print_binary(sendMsg.packet[1]);
  printf("\t");
  print_binary(sendMsg.packet[2]);
  printf("\t");
  print_binary(sendMsg.packet[4]);
  printf("\t\n");

   size_t n = sizeof(struct data_t);
   printf("Size: %lu\n",n);
   uint8_t * out;
   int i = 0;

   printf("sendmsg packet: \n");
   while(i < n)
   {
      out = &sendMsg.packet[i];
      print_binary(* out);
      printf("\t");
      i++;

   }
   printf("\n");
   i = 0;
   while(i < n)
   {
      out = &sendMsg.packet[i];
      printf("%x",(* out));
      printf("\t");
      i++;
   }
   printf("\n");
   i = 0;
   while(i < n)
   {
      out = &sendMsg.packet[i];
      printf("%c",((char)* out));
      printf("\t");
      i++;
   }
   */
}
