
#include <stdio.h>
#include <stdint.h>



float arr[18] = { 0 };


// array statistics
struct arrStat
{
    float min;
    float max;
    float mean;
    int incCount;
    int decCount;
    int incSeqCount;
    int decSeqCount;
    float diff;
    float incMaxDiff;
    float decMaxDiff;
};

struct arrStat result;


// compute simple average from array of values
float computeAvg(float v[], uint8_t sz)
{
  // compute average
  float sum = 0, avg;
  for(int i = 0; i<sz; i++)
  {
    sum += v[i];
  }
  return avg = sum / sz;
}

// find max from array of values
float computeMax(float v[], uint8_t sz)
{
  float m = 0;
  for(int i = 0; i<sz; i++)
  {
    m = (v[i] > m) ? v[i] : m;
  }
  return m;
}

// find max from array of values
float computeMin(float v[], uint8_t sz)
{
  float m = 0;
  for(int i = 0; i<sz; i++)
  {
    m = ((i == 0) || (v[i] < m)) ? v[i] : m;
  }
  return m;
}


/**
 * For n datapoints in array of float values
 * determine:
 *  min, max, mean
 *  overall margin change  +/- (first to last)
 *  count of sequential (monotonic) increasing / decreasing elements
 *  culmulative count of periods with increase / decrease
 *  max diff (increase/decrease change) between two data points
 *
 * @param float array
 * @param int sz number of elements
*  @param struct arraStat (pointer)
 * @return void
 *
 */
void computeArrStats(float arr[], int sz, struct arrStat *result)
{

  // init result struct values
  result->min = 0;
  result->max = 0;
  result->mean = 0;
  result->incSeqCount = 0;
  result->decSeqCount = 0;
  result->incCount = 0;
  result->decCount = 0;
  result->incMaxDiff = 0;
  result->decMaxDiff = 0;

  result->min = computeMin(arr, sz);
  result->max = computeMax(arr  , sz);
  result->mean = computeAvg(arr, sz);
  result->diff = arr[sz-1] - arr[0]; // difference between last / first data points


  int period = 1;

  // sequential (monotonic) & cumulative increase / decrease counters
  int incSeqCount = 0;
  int decSeqCount = 0;
  int incCumCount = 0;
  int decCumCount = 0;

  for(int i = sz; i > 1; i--)
  {
    float curr = arr[sz - i + period];
    float prev = arr[sz - i];

    if ( curr > prev) // increase (rise)
    {
      incCumCount++;
      incSeqCount++;
      if (incSeqCount > result->incSeqCount)
      {
        result->incSeqCount = incSeqCount;
      }
      decSeqCount = 0;

      float diff = curr - prev;
      if (diff > result->incMaxDiff)
      {
        result->incMaxDiff = diff;
      }

    } else if (curr < prev) { // decrease (fall)
      decCumCount++;
      decSeqCount++;
      if (decSeqCount > result->decSeqCount)
      {
        result->decSeqCount = decSeqCount;
      }
      incSeqCount = 0;

      float diff = prev - curr;
      if (diff > result->decMaxDiff)
      {
        result->decMaxDiff = diff;
      }
    }
  }

  result->incCount = incCumCount;
  result->decCount = decCumCount;
}


int main()
{

  int arrSz = 18;

  arr[0] = 101385.71;
  arr[1] = 101390.10;
  arr[2] = 101388.30;
  arr[3] = 101387.21;
  arr[4] = 101388.40;
  arr[5] = 101392.80;
  arr[6] = 101394.80;
  arr[7] = 101389.60;
  arr[8] = 101391.71;
  arr[9] = 101389.00;
  arr[10] = 101389.10;
  arr[11] = 101341.40;
  arr[12] = 101344.30;
  arr[13] = 101350.71;
  arr[14] = 101348.71;
  arr[15] = 101357.80;
  arr[16] = 101370.30;
  arr[17] = 101374.21;

  computeArrStats(arr, arrSz, &result);

  for(int i=0;i<arrSz; i++)
  {
      printf("%d \t %f \n", i, arr[i]);
  }

  printf("Min: %f \n",result.min);
  printf("Max: %f \n",result.max);
  printf("Mean: %f \n",result.mean);
  printf("Inc Count: %d \n",result.incCount);
  printf("Dec Count: %d \n",result.decCount);
  printf("Inc Seq Count: %d \n",result.incSeqCount);
  printf("Dec Seq Count: %d \n",result.decSeqCount);

  printf("Diff: %f \n",result.diff);
  printf("Inc Max Diff: %f \n",result.incMaxDiff);
  printf("Dec Max Diff: %f \n",result.decMaxDiff);

}
