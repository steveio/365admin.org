#ifndef __RINGBUFS_H
#define __RINGBUFS_H
#define RBUF_SIZE    128
#endif


typedef struct  ringBufS    {
  unsigned char buf[RBUF_SIZE];
  int head;
  int tail;
  int count;
} ringBufS;


void  ringBufS_init  (ringBufS *_this);
int   ringBufS_empty (ringBufS *_this);
int   ringBufS_full  (ringBufS *_this);
int   ringBufS_get   (ringBufS *_this);
void  ringBufS_put   (ringBufS *_this, const unsigned char c);
void  ringBufS_flush (ringBufS *_this, const int clearBuffer);



void ringBufS_init (ringBufS *_this)
{
   memset (_this, 0, sizeof (*_this));}
