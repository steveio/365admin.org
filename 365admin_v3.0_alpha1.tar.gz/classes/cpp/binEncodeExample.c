#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct SensorData
{
    int sensorId;
    float v1;
    float v2;
    long v3;
    char v4[20];
};

int main()
{
    struct SensorData data={101, 3.142, -11.6, 604421198, "N NE E SE S"};
    //declare character buffer (byte array)
    unsigned char *buffer=(char*)malloc(sizeof(data));
    int i;

    //copying....
    memcpy(buffer,(const unsigned char*)&data,sizeof(data));

    printf("Copied byte array is:\n");
    for(i=0;i<sizeof(data);i++)
        printf("0x%02x\t", buffer[i]);
    printf("\n");

    //freeing memory..
    free(buffer);
    return 0;
}
