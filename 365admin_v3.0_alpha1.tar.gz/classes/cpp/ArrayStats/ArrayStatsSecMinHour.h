/**

ArrayStatsSecMinHour.h

Wrapper for ArrayStats library to maintain rolling second, minute & hour statistics

Useage:

*/


#ifndef ARRAY_STATS_SECMINHOUR_H_
#define ARRAY_STATS_SECMINHOUR_H_


#define LIBRARY_VERSION 1.1.0


dev1ArrayStats.add()

class ArrayStatsContainer {
    public:
      ArrayStatsContainer();
      ArrayStats(ArrayStats sec, ArrayStats min, ArrayStats hour);
      void add(const float f);
      ~ArrayStats();

    protected:
      ArrayStats _sec;
      ArrayStats _min;
      ArrayStats _hour;
};


#endif //ARRAY_STATS_H_
