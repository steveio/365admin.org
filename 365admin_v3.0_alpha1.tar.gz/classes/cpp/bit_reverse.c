#include <stdio.h>
#include <stdint.h>
#include <limits.h>
#include <stdbool.h>


int main()
{

  bool f = 1;         // conditional flag
  unsigned int m = 2; // the bit mask
  unsigned int w = 0; // the word to modify:  if (f) w |= m; else w &= ~m;

  w ^= (-f ^ w) & m;

  printf("%d \n",w);
  printf("%X \n",w);

  // OR, for superscalar CPUs:
  w = (w & ~m) | (-f & m);

  printf("%d \n",w);
  printf("%X \n",w);


  /*

  const unsigned int n = 42;          // numerator
  const unsigned int s = 4;
  const unsigned int d = 1U << s; // So d will be one of: 1, 2, 4, 8, 16, 32, ...
  unsigned int m;                // m will be n % d
  m = n & (d - 1);

  0010 1010
  0000 1111

  0000 1010

  printf("%d \n",d);

  printf("%d \n",m);


  unsigned int v = 43;     // input bits to be reversed
  unsigned int r = v; // r will be reversed bits of v; first get LSB of v

  printf("%d \n",v);
  printf("%d \n",r);

  int s = sizeof(v) * CHAR_BIT - 1; // extra shift needed at end


  for (v >>= 1; v; v >>= 1)
  {
    r <<= 1;
    r |= v & 1;
    s--;
  }
  r <<= s; // shift when v's highest bits are zero

  printf("%d \n",v);
  printf("%d \n",r);

  printf("%X \n",v);
  printf("%X \n",r);
  */
}
