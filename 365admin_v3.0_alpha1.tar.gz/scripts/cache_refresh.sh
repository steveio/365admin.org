#!/bin/bash


/usr/bin/php /www/vhosts/oneworld365.org/htdocs/cache_content_freq.php oneworld365.org
