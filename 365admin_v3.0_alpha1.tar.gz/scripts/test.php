<?

print phpinfo();

?>
